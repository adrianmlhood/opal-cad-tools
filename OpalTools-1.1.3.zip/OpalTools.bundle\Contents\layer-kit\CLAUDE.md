# LayerKit — Claude Session Context
# AutoCAD layer/utility tools | Ocotillo Labs | Adrian Hood | AutoCAD 2027
#
# Sibling project to Stringtag and Opal — same AutoLISP engine and loader pattern,
# its own naming/data model. Full AutoLISP coding standards live in ..\Stringtag\CLAUDE.md;
# this file carries the LayerKit specifics plus the must-not-break rules restated so this
# subtree is self-sufficient.

---

## What this suite is
- A home for LK-prefixed AutoCAD **layer/utility** tools. Root: `C:\Users\adria\CAD\Automations\layer-kit\`
- Commands are **`LK-`-prefixed**. Active tool folders: `LK-CLEANUP` [Full/Preview] (+ the
  `LK-APPLY` orchestrator), `LK-STD` [Save/Set/Config], `LK-FILTER` [Set/Save], `LK-DIMS`,
  `LK-ZEROBLOCK` (alias `LK-ZB`), and `LK-LOAD`/`LKLOAD`. (Multi-action commands use a getkword
  sub-option prompt; the old one-command-per-action names are now internal `lk:` helpers. Files
  stay split per tool for QA.)
- ⚠ **`LK-BYLAYER` / `LK-SKIP` are currently SHELVED:** their folder is under `archive/lkbylayer/`,
  which `LK-LOAD` skips, so those commands do **not** load. FEATURES.md still documents them.
  Re-activate by moving `lkbylayer/` back to the LayerKit root. (Confirm whether this is intended.)
- Tools today: **LK-CLEANUP/LK-APPLY** (classify → rename/merge/purge → standards/filters),
  **LK-STD**, **LK-FILTER**, **LK-DIMS** (DIMENSIONs to front + DIMTFILL mask), **LK-ZEROBLOCK**
  (pick a block → push all nested geometry to layer 0). New utilities are added as new tool folders.
- NOTE: was `PV-`-prefixed through pvcleanup-1.03; rebranded to `LK-` at lkcleanup-1.04
  (full PV→LK rename: commands, `lk:` helpers, `*lk-config-dir*`, folders). The old PV-named
  tool folders are preserved under `archive\pre-LK-rebrand\`.
- Per-tool feature registry: **`FEATURES.md`** — read it before iterating any tool and update
  it at write time. Everything is NON-WORKING until confirmed in a live AutoCAD drawing.
- **`README.md`** is the human-facing overview (commands, loading, folder layout, CSVs). Keep
  it current: update it on **significant** changes — a new/removed command, a change to how the
  suite loads, or a change to the config/CSV model. Routine version bumps and internal tweaks
  go in `FEATURES.md` only, not the README.

## Loader & project structure
- Each tool lives in its own folder named for the command stem (`lkcleanup/`, ...).
- `layerkit-load.lsp` loads `lkload/lkload-1.6.lsp` and calls `(C:LK-LOAD)` on every session
  (quiet mode). **Deliberately NOT named `acad.lsp`** — AutoCAD auto-loads only the first
  `acad.lsp` on the support path, which would collide with `Opal\acad.lsp`. Load LayerKit via
  APPLOAD → Startup Suite, or one `(load ".../layerkit-load.lsp")` line in your single real
  `acad.lsp`/`acaddoc.lsp`.
- **LK-LOAD loads the highest-versioned `.lsp` in every tool folder.** Skips `lkload`,
  `config`, `archive`, `test`, `tools`. To ship a fix you just write the next version file —
  no loader edit needed. Tracks loaded versions in `*lkload-versions*` alist.
- Loose root files are limited to `layerkit-load.lsp`, `CLAUDE.md`, `FEATURES.md`. Data CSVs
  live in `config/`; parked reference artifacts (zip, flow diagram, old logs) live in `archive/`.

## Session protocol (versioning — same scheme as Stringtag/Opal)
- **Default to `+0.01`** for almost everything — bug fixes AND incremental features
  (`1.0 → 1.01`). Small steps are the norm.
- Round up to the next `x.N0` only for a genuine milestone (a major new mode or substantial
  rework). `+1.0` only for a full rewrite.
- **Copy-first-then-edit:** the new version file must exist before any edits; never edit the
  highest-versioned file in place.
- **Update `FEATURES.md` at write time:** add new features as `[x.xx untested]`; drop
  `untested` only after the user confirms in AutoCAD; move removed behavior to a `### Dropped`
  block with a reason. Helper commands are listed as features of their parent tool, not as
  separate sections.

## Config / data model (CSV-driven — different from Opal's layer globals)
- LayerKit is **data-driven by CSV**, not by `*ocfg-*` layer globals. LK-CLEANUP reads
  `PV_static_mappings.csv` (exact source→target map) and `PV_keywords.csv` (token→target).
  (CSV filenames keep the `PV_` prefix — solar/PV data, not commands; only code identifiers
  were rebranded.)
- Master/template copies live in `config/`. At runtime the tool defaults its config dir to
  **`DWGPREFIX`** (the open drawing's folder) via `lk:get-config-dir`; `LK-STD` > Config (or setting
  `*lk-config-dir*`) overrides it and persists it to the registry
  (`HKCU\Software\Ocotillo\LayerKit` → `ConfigDir`). The "Hard" assignment path appends to the
  static CSV and a `PV_mapping_log.csv` is written in the config dir.

## Critical AutoLISP rules (full set in ..\Stringtag\CLAUDE.md)
- **Reserved words — never use as variable names** (causes silent "syntax error"):
  `mod and or not car cdr cons list read set type max min if while foreach cond defun setq` …
  — `mod` is the usual culprit.
- **Entity creation:** prefer `entmakex`. `getpoint` returns UCS → `(trans pt 1 0)` to WCS.
- **All entities ByLayer** for any deliverable geometry (`(cons 62 256)`); layers explicit,
  never via CLAYER.
- Verify paren depth returns to 0 before saving. No `vl-sort` / `mapcar` with a quoted lambda
  (can cancel the load) — use `foreach` + accumulator or insertion sort.
- **Loader version sort is ASCII**, not numeric: use `1.09`/`1.10`, never `1.9`/`1.10`.

## Differences from Stringtag / Opal (fork notes)
- Commands are `LK-`-prefixed, **not** Stringtag's 4-char S-names or Opal's dashed+undashed
  O-names. Loader is `LK-LOAD` (alias `LKLOAD`); tool folders start with `lk`.
- No `oconfig`-style layer-globals tool — LayerKit's "config" is the runtime CSV directory.
- `"ucd"` = update this CLAUDE.md (user follows with what to add).
