# O-Suite — Claude Session Context
# Opal Energy deployment | Adrian Hood | AutoCAD 2027 (full)
#
# Forked from the Stringtag suite — same AutoLISP engine, different naming/layers/loader.
# Full AutoLISP coding standards live in ..\Stringtag\CLAUDE.md; this file carries the
# O-Suite specifics and the new "O-approach", plus the critical rules restated so this
# subtree is self-sufficient.

---

## What this suite is
- Parallel toolset to Stringtag, deployed at Opal Energy. Root: `C:\Users\adria\CAD\Automations\opal-tools\`
- Commands are **O-prefixed with dashed + undashed aliases** (`O-DC` and `ODC`, `O-LOAD` and `OLOAD`).
- Per-tool feature registry: **`FEATURES.md`** — read it before iterating any tool and update it at write time (see Session Protocol). Everything is NON-WORKING until confirmed in a live AutoCAD drawing.

## Loader & project structure
- Each tool lives in its own folder named for the command (`odc/`, `oset/`, `oload/`, `oconfig/`, ...).
- `acad.lsp` loads `oload/oload-1.02.lsp` and calls `(C:O-LOAD)` on every session.
- **O-LOAD loads `oconfig` first** (layer globals), then the **highest-versioned `.lsp` in every tool folder**. Skips `oload`, `oconfig`, `test`, `tools`. So to ship a fix you just write the next version file — no loader edit needed.
- **Dormant:** `dormant\` holds whole shelved tool directories that O-LOAD does not scan. **The USER manages dormant — Claude does NOT move files there.** Do not "archive older versions" or prune the active folder; leave every version file in its tool folder (O-LOAD just loads the highest). The user moves an entire tool directory into `dormant\` when shelving it, and back out when work resumes.

## Session protocol (versioning — same scheme as Stringtag)
- **Default to `+0.01` for almost everything** — bug fixes AND incremental features (`1.20 → 1.21`). Don't jump versions; small steps are the norm.
- Round up to the next `x.N0` only for a genuine milestone (a major new mode or substantial rework), NOT routine feature tweaks.
- `+1.0` only for a full rewrite.
- **Copy-first-then-edit:** the new version file must exist before any edits; never edit the highest-versioned file in place.
- **Update `FEATURES.md` at write time:** add new features as `[x.xx untested]`; drop `untested` only after the user confirms in AutoCAD; move removed behavior to a `### Dropped` block with a reason.
- `"ucd"` = update this CLAUDE.md (user follows with what to add).

## Layers are config-driven (NEVER hardcode a layer string)
- `oconfig/oconfig-1.0.lsp` sets every `*ocfg-layer-*` global — the **only** place layer names live. Key ones:
  `*ocfg-layer-modules*` = `"MODULES"` (module source geometry), `*ocfg-layer-dc*` = `"E-STRINGING"` (O-DC string path),
  `*ocfg-layer-stringing*` / `-fill*` / `-count*`, `*ocfg-layer-homerun-n*` / `-p*`, `*ocfg-layer-jump*`,
  `*ocfg-layer-pv-tags*`, `*ocfg-layer-schedules*`, `*ocfg-layer-conduit*`, ...
- Tools read layer names from these globals. To redeploy for a different client, **replace `oconfig` only**.
- **All entities ByLayer:** `(cons 62 256)`. The layer carries color/linetype. (ByLayer-only is the deliverable standard — no per-entity colored fills.)

## ★ Module geometry — the core of the O-approach (READ THIS)
Opal drawings draw each module as an **OLD-STYLE HEAVYWEIGHT `POLYLINE`** (DXF type `"POLYLINE"`),
**not** `LWPOLYLINE`. A heavy POLYLINE's corners are **not** in its own `entget` — they live in separate
`VERTEX` sub-entities after the header, terminated by `SEQEND`.

**Consequence:** any tool that selects modules with `ssget '((0 . "LWPOLYLINE")))` finds **ZERO** modules
on these drawings. This was the root cause of O-DC failing.

**Module-detection standard for every O-Suite geometry tool:**
1. **Filter POSITIVELY to the module layer** — Opal modules live on `*ocfg-layer-modules*` (currently `"PV-MODS"`, oconfig 1.03). Collect by type AND layer: `(ssget "X" (list '(0 . "*POLYLINE") (cons 8 *ocfg-layer-modules*)))`. `"*POLYLINE"` matches BOTH `"POLYLINE"` and `"LWPOLYLINE"`.
   - ⚠ **Do NOT use a denylist** ("any polyline not on a tool layer"). A real construction drawing has ~10k structure / annotation / dimension polylines, so a denylist over-collects massively and clicks land inside giant non-module polylines whose center is off in the void. This was the O-DC v1.09 → v1.10 bug (scan said 10554 modules; real = 371). Keep `_oset-non-module-layer` only as a fallback for untagged drawings that have no module layer.
2. Read corners with a dual path (reference: `_odc-poly-pts` / `_odc-poly-bbox` in `odc/odc-1.10.lsp`):
   - `LWPOLYLINE`: group-10 pairs in `entget`.
   - `POLYLINE`: `(entnext)` walk while the next entity's type is `"VERTEX"`; read each VERTEX group 10.
   - **OCS→WCS with the entity-name form `(trans pt ent 0)`**, NOT the integer `(trans pt 2 0)` — the integer form is ambiguous; the entity-name form is correct for any extrusion.
3. A module = a closed POLYLINE/LWPOLYLINE on the module layer (O-SET expects exactly 4 verts; O-DC accepts ≥3).

**O-SET is FIXED (1.04+, current `oset-1.13.lsp`):** it uses the `(0 . "*POLYLINE")` + VERTEX-walk dual reader (`_oset-poly-pts`), is fully automatic (no click), defines a module by the modal footprint and filters out non-module clutter on PV-MODS, and reports one or two row spacings. Tools that still have the old `LWPOLYLINE`-only bug are all dormant (`ocount-1.0`, `ojump-1.0`) — fix them the same way if reactivated. O-DC uses bbox containment, so it no longer needs O-SET calibration.

## ★ Graceful degradation — layer fallback (never dead-end on a renamed layer)
A tool that selects by a `*ocfg-layer-*` name must degrade gracefully when that layer is empty
(client renamed it, stray export, untagged drawing). The standing pattern — apply it to every
geometry tool, and it keeps tools from getting locked into one workflow:
1. **Try the configured layer first** (positive filter, per the module-detection standard above).
2. **If that finds NOTHING, fall back to a shape-gated scan of ALL layers** — keep only objects
   whose geometry matches the expected footprint (modules: 4-corner AND (short,long) within tol of
   a `*ocfg-modules*` entry). The config dims anchor the match, so this is **NOT** the forbidden
   denylist — structure/annotation clutter is never pulled in.
3. **Announce the fallback** (print which path was used + the count) so the user knows.
Canonical: `_ogeo-all-modules` (ogeo, shared) and `_oset-config-match` (oset, self-contained).

## ★ Viewport-visibility filter — ignore module-shaped clutter outside the documented field
A real module is shown inside a layout viewport. `_ogeo-all-modules` (ogeo 1.02+) ends with
`_ogeo-filter-shown`: any module-shaped object whose centre is not inside SOME layout viewport's
model-space window is ignored — template copies parked in model space, modules drawn on cutsheet/
detail areas. This locks every consuming tool (O-MODSPACE, O-PVSPACE, O-GRID, O-MODSIZE) onto the
one documented concentration of modules, so a stray near a click can never be seeded or flooded.
- View windows come from the **VLA `AcadPViewport` properties** (`ViewCenter`/`ViewHeight`/`Width`/
  `Height`/`TwistAngle`) — model-space by definition, unlike the DCS-relative raw DXF group 12.
  Plan-view only; the paper-background viewport (DXF id 1) is skipped; twist-aware; clipped/3D
  viewports are kept permissively (never drop a real module on a geometry edge case).
- **Safe by design — never strands real modules:** disabled by `*ocfg-filter-viewport*` (oconfig,
  default T); if the drawing has NO viewports, or the filter would drop EVERY module, it keeps all.
  It reports the count ignored. Caveat: if sheets don't yet frame the whole field, real modules
  outside every viewport are dropped — toggle the flag off for in-progress drawings.

## ★ Array tool family (size / spacing / both)
Composable commands over one shared core (`ogeo`). Array detection is proximity flood-fill
(`_ogeo-array-from`) from a seed; the seed is either a clicked module or the module NEAREST a
clicked point. Interaction conventions:
- **Anchor point (OSNAP on)** where a fixed reference is needed (O-MODSPACE Set, O-PVSPACE,
  O-GRID): the array = nearest module to the point; the point also selects the FIXED row/col (the
  groups nearest it stay put). The point need NOT land on a module — this is how an array with no
  module at the corner is handled. Pick with `(setvar "OSMODE" (logior old-os 1))` (endpoint on),
  restore after.
- **Click-near (OSNAP off)** for read-only (O-MODSPACE Measure): nearest module identifies the array.

Tools:
- **O-MODSIZE** — size only: normalize every module to one footprint (Report / Normalize).
- **O-MODSPACE** — spacing only, ONE array: rows AND columns (Set = anchor-point; Measure =
  click-near). Was O-ROWSPACE (folder `orespace/`, shelved); now `omodspace/`, helpers `_omsp-*`.
  Rows step along the module SHORT edge, columns along the LONG edge. North-bay (only) also picks
  an edge-validated north-row module to set the odd-bay end. The reusable Set engine is `_omsp-set-one`.
- **O-PVSPACE** — batch (two-phase): batch-pick every array's anchor point, prompt ONCE for
  rows + columns (north end picked once, reused), then one combined confirm applies that param set
  to all picked arrays via `_omsp-apply-one` (`opvspace/`).
- **O-GRID** — the union: resize **and** snap an array to an ideal lattice from a fixed corner.
Don't re-implement geometry/spacing — extend `ogeo` / reuse the `_omsp-*` engine across all of these.

## ★ Module orientation — Opal modules are ROTATED in the drawing
Opal relies heavily on **Solesca** exports rather than Helioscope (which the original
Stringtag suite was built against). Solesca exports modules as rotated polylines whose
sides follow the site/racking orientation — they are NOT axis-aligned to WCS. Helioscope
exports produce axis-aligned modules, so this issue never surfaced in Stringtag.

Opal modules are NOT axis-aligned to WCS. Their polyline sides are at an angle (typically
matching the site plan / racking orientation). This has two consequences for any tool that
draws indicators, arrowheads, or markers AT a module:

1. **Never orient an indicator to the WCS X/Y axes.** A square whose corners are at
   `(cx±h, cy±h)` looks like a diamond rotated 45° relative to the module grid. This was
   the O-DC 1.22 bug.

2. **Never orient an indicator to the STRING/PATH direction.** A square rotated to match
   the connecting line points diagonally whenever the string segment is not parallel to the
   module grid. This was the O-DC 1.21 bug.

**Correct approach: derive orientation from the MODULE's own polyline edge.**
```lisp
(defun _odc-mod-dir (ent / pts p0 p1 dx dy len)
  (setq pts (_odc-poly-pts ent))
  (if (>= (length pts) 2)
    (progn
      (setq p0 (car pts) p1 (cadr pts)
            dx (- (car p1) (car p0)) dy (- (cadr p1) (cadr p0))
            len (sqrt (+ (* dx dx) (* dy dy))))
      (if (> len 1e-9) (list (/ dx len) (/ dy len)) (list 1.0 0.0)))
    (list 1.0 0.0)))
```
Call this with the module entity (`(car rec)` from the module record). Any adjacent-corner
pair works — the square has 4-fold symmetry so long-axis vs short-axis doesn't matter.
Pass the resulting vector as the `dir` argument to the box-drawing function so ux/uy/vx/vy
align to the module sides. Canonical implementation: `_odc-mod-dir` in `odc/odc-1.23.lsp`.

## ★ Pick-based interaction pattern (the O-DC model)
Canonical reference: `odc/odc-1.10.lsp` (`C:O-DC`). For any "click modules → draw geometry" tool:
- **OSNAP off:** `(setq old-os (getvar "OSMODE"))` → `(setvar "OSMODE" 0)`; restore at normal end AND in `*error*`. (OSNAP on pulls `getpoint` to module corners and corrupts the containment test.)
- **Local `*error*` handler:** clear highlights, restore `OSMODE`/`CMDECHO`, restore previous `*error*`. Save `(setq old-err *error*)` and also restore at normal end.
- **"Inside the module" = click is inside the module's bounding box.** Pre-collect `(ent + bbox + center)` once before the loop; per click `(trans pt 1 0)` (UCS→WCS) then test containment with a nearest-center tiebreak. A click inside no module is **ignored** (re-prompt) — never snapped to a distant entity.
- **Draw the REAL geometry immediately with `entmakex`** so it appears during the command (entmade entities display at once). Do NOT rely on `grdraw` previews that vanish on redraw, and do NOT defer all drawing to after the loop.
- **Live feedback:** `(redraw ent 3)` highlights a picked entity, `(redraw ent 4)` clears it; track picked ents and clear at end / in `*error*`.
- A straight `LINE` between two true centers is automatically horizontal / vertical / diagonal — no special-casing, no row-normalization.

## Critical AutoLISP rules (full set in ..\Stringtag\CLAUDE.md)
- **Reserved words — never use as variable names** (causes silent "syntax error"): `mod and or not car cdr cons list read set type max min if while foreach cond defun setq` ... — `mod` is the usual culprit.
- **Entity creation:** `entmakex` only (never `entmake` / `command`). `getpoint` returns UCS → `(trans pt 1 0)` to WCS before `entmakex`. LWPOLYLINE/VERTEX group 10 is OCS → `(trans pt 2 0)`.
- **`ssget` with point args uses UCS** — pass the raw UCS point, not a WCS-transformed one (matters on rotated UCS / site plans).
- No `apply 'min` / `apply 'max` — use `_xxx-list-min` / `_xxx-list-max` helpers. No `vl-sort` / `mapcar` with a quoted lambda (causes load cancel) — use `foreach` + accumulator or insertion sort. `foreach` can't break early — use `while` with an index.
- Verify paren depth returns to 0 before saving. Layers explicit, never via CLAYER.
- XDATA namespace `"OCOTILLO"` (shared with Stringtag → suites interoperate); helpers are `_oxd-*` in `O-XLIB`.

## *oset-* calibration globals (O-SET)
`*oset-mod-w*`, `*oset-mod-h*`, `*oset-gap-x*`, `*oset-gap-y*`. Center-to-center: col = `mod-w + gap-x`, row = `mod-h + gap-y`. (O-SET is currently LWPOLYLINE-only — see Known Bug.)

## Differences from Stringtag (fork notes)
- Commands O-prefixed with aliases (`O-DC`/`ODC`), **not** 4-char S-names. Loader is `O-LOAD` and tool folders start with `o` (not `SLOAD` / `s`).
- Layers are `*ocfg-*` config globals with Opal client names (`PV-…`, `E-…`), **not** the Stringtag fixed names (`module`, `dc-arrow`, …).
- Calibration/config globals are `*oset-*` / `*ocfg-*` (not `*sset-*`); XDATA helpers `_oxd-*` (not `_sxd-*`); same `"OCOTILLO"` namespace.
